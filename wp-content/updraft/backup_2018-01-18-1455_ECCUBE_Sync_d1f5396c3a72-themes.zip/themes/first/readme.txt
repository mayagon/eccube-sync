Readme
==============================

First is a simple yet flexible WordPress theme for blogs. From beginner bloggers to pro bloggers, it has features for everyone.

First is made using responsive design, so it offers a pleasant reading experience even on tablets and smartphones.

First comes with 4 widgets and 3 menus. Because the Customizer also allows you to set up custom headers and backgrounds, you can set your blog up just the way you want it.

Theme URI: http://themehaus.net/themes/first/


License
--------------------

First WordPress Theme, Copyright 2014-2016 Takao Utsumi
First is distributed under the terms of the GNU GPL

First is based on Underscores
Underscores is distributed under the terms of the GNU GPL
http://underscores.me/

First incorporates code from Twenty Thirteen
Twenty Thirteen is distributed under the terms of the GNU GPL
http://wordpress.org/themes/twentythirteen

First incorporates code from Stargazer
Stargazer is distributed under the terms of the GNU GPL
http://wordpress.org/themes/stargazer

First bundles the following third-party resources:

* normalize.css is licensed under MIT (http://necolas.github.io/normalize.css/)
* Genericons are licensed under GPL2 (http://genericons.com/)
* html5shiv.js is dual licensed under MIT & GPL2 (https://github.com/aFarkas/html5shiv)
* Open Sans font from Google Fonts is licensed under Apache License 2.0 (https://www.google.com/fonts/specimen/Open+Sans)
* The photo on the screenshot is licensed under CC0 (http://unsplash.com/post/71804697474/download-by-diogo-tavares)
